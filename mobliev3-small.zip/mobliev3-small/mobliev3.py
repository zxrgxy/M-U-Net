import warnings
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as F
from PIL import Image
import numpy as np
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torch.amp import autocast, GradScaler
from tqdm import tqdm
import pandas as pd
import matplotlib.pyplot as plt
import random

# 禁用albumentations的版本检查
os.environ['ALBUMENTATIONS_DISABLE_VERSION_CHECK'] = '1'
# 过滤不必要的警告
warnings.filterwarnings("ignore", category=UserWarning, module="albumentations")
warnings.filterwarnings("ignore", category=FutureWarning, module="torch")

# 设置PyTorch数值稳定性选项
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.deterministic = False


# 配置参数
class Config:
    # 数据路径
    train_data_path = r"E:\shuju_S2\dset-s2\yangben\xunlian\shujuji"
    train_mask_path = r"E:\shuju_S2\dset-s2\yangben\xunlian\yangbenji"
    test_data_path = r"E:\shuju_S2\dset-s2\yangben\ceshi\shujuji"
    test_mask_path = r"E:\shuju_S2\dset-s2\yangben\ceshi\yangbenji"
    predict_data_path = r"E:\shuju_S2\dset-s2\shuchushuju_png"

    # 训练参数
    batch_size = 16
    epochs = 200
    lr = 0.001
    min_lr = 1e-6  # 最小学习率
    num_workers = 0
    pin_memory = True
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    use_amp = True
    amp_dtype = torch.float16  # 混合精度类型

    # 学习率调度器参数
    cosine_t_max = 20
    cosine_eta_min = 1e-6

    # 模型保存路径
    save_path = "../waternet_mobilenetv3.pth"

    # 日志和输出保存路径
    logs_path = "../training_logsV3"
    epoch_outputs_path = "../epoch_outputsV3"
    analysis_path = "../training_analysis"

    # 模型和训练配置
    gradient_clip_val = 1.0  # 梯度裁剪阈值
    checkpoint_every = 10  # 每n个epoch保存一次检查点
    seed = 42  # 随机种子


# 设置随机种子以确保可重复性
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# 导入MobileNetV3-Small模型（精简版）
def _make_divisible(ch, divisor=8):
    return max(divisor, int(ch + divisor / 2) // divisor * divisor)


class ConvBNActivation(nn.Sequential):
    def __init__(self, in_planes, out_planes, kernel_size=3, stride=1, groups=1):
        super().__init__(
            nn.Conv2d(in_planes, out_planes, kernel_size, stride, (kernel_size - 1) // 2, groups=groups, bias=False),
            nn.BatchNorm2d(out_planes),
            nn.ReLU6(inplace=True)
        )


class SqueezeExcitation(nn.Module):
    def forward(self, x):
        scale = F.adaptive_avg_pool2d(x, 1)
        scale = self.fc2(F.relu(self.fc1(scale), inplace=True))
        return x * F.hardsigmoid(scale, inplace=True)

    def __init__(self, input_c, squeeze_factor=4):
        super().__init__()
        squeeze_c = _make_divisible(input_c // squeeze_factor)
        self.fc1 = nn.Conv2d(input_c, squeeze_c, 1)
        self.fc2 = nn.Conv2d(squeeze_c, input_c, 1)


class InvertedResidual(nn.Module):
    def forward(self, x):
        result = self.block(x)
        return result + x if self.use_res_connect else result

    def __init__(self, cnf):
        super().__init__()
        self.use_res_connect = cnf.stride == 1 and cnf.input_c == cnf.out_c

        layers = []
        if cnf.expanded_c != cnf.input_c:
            layers.append(ConvBNActivation(cnf.input_c, cnf.expanded_c, kernel_size=1))

        layers.append(ConvBNActivation(cnf.expanded_c, cnf.expanded_c,
                                       kernel_size=cnf.kernel, stride=cnf.stride, groups=cnf.expanded_c))

        if cnf.use_se:
            layers.append(SqueezeExcitation(cnf.expanded_c))

        layers.append(nn.Sequential(
            nn.Conv2d(cnf.expanded_c, cnf.out_c, 1, bias=False),
            nn.BatchNorm2d(cnf.out_c),
            nn.Identity()
        ))

        self.block = nn.Sequential(*layers)


class MobileNetV3(nn.Module):
    def _forward_impl(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

    def forward(self, x):
        return self._forward_impl(x)

    def __init__(self, inverted_residual_setting, last_channel, num_classes=1000):
        super().__init__()

        firstconv_output_c = inverted_residual_setting[0].input_c
        self.features = nn.Sequential(
            ConvBNActivation(3, firstconv_output_c, kernel_size=3, stride=2),
            *[InvertedResidual(cnf) for cnf in inverted_residual_setting],
            ConvBNActivation(inverted_residual_setting[-1].out_c, 6 * inverted_residual_setting[-1].out_c,
                             kernel_size=1)
        )

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(
            nn.Linear(6 * inverted_residual_setting[-1].out_c, last_channel),
            nn.Hardswish(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(last_channel, num_classes)
        )

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)


def mobilenet_v3_small(width_multi=1.0):
    bneck_conf = lambda input_c, kernel, expanded_c, out_c, use_se, activation, stride: \
        type('InvertedResidualConfig', (object,), {
            'input_c': _make_divisible(input_c * width_multi),
            'kernel': kernel,
            'expanded_c': _make_divisible(expanded_c * width_multi),
            'out_c': _make_divisible(out_c * width_multi),
            'use_se': use_se,
            'use_hs': activation == "HS",
            'stride': stride
        })()

    inverted_residual_setting = [
        bneck_conf(16, 3, 16, 16, True, "RE", 2),
        bneck_conf(16, 3, 72, 24, False, "RE", 2),
        bneck_conf(24, 3, 88, 24, False, "RE", 1),
        bneck_conf(24, 5, 96, 40, True, "HS", 2),
        bneck_conf(40, 5, 240, 40, True, "HS", 1),
        bneck_conf(40, 5, 240, 40, True, "HS", 1),
        bneck_conf(40, 5, 120, 48, True, "HS", 1),
        bneck_conf(48, 5, 144, 48, True, "HS", 1),
        bneck_conf(48, 5, 288, 96, True, "HS", 2),
        bneck_conf(96, 5, 576, 96, True, "HS", 1),
        bneck_conf(96, 5, 576, 96, True, "HS", 1)
    ]

    last_channel = _make_divisible(1024 * width_multi)
    return MobileNetV3(inverted_residual_setting, last_channel)


# 自注意力模块 - 数值稳定性改进
class SelfAttentionModule(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.query = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.value = nn.Conv2d(in_channels, in_channels, 1)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        b, c, h, w = x.size()
        q = self.query(x).view(b, -1, h * w).permute(0, 2, 1)  # [B, N, C]
        k = self.key(x).view(b, -1, h * w)  # [B, C, N]
        v = self.value(x).view(b, -1, h * w)  # [B, C, N]

        # 缩放点积注意力，提高数值稳定性
        attention = torch.bmm(q, k) / (q.size(-1) ** 0.5)
        attention = self.softmax(attention)

        out = torch.bmm(v, attention.permute(0, 2, 1)).view(b, c, h, w)
        return self.gamma * out + x


# 特征融合模块
class FeatureFusionModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x1, x2):
        if x1.size()[2:] != x2.size()[2:]:
            x2 = F.interpolate(x2, size=x1.size()[2:], mode='bilinear', align_corners=False)
        return self.conv(torch.cat([x1, x2], dim=1))


# 空间金字塔池化模块 - 帮助识别不同尺度的水体
class SpatialPyramidPooling(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 2, kernel_size=1),
            nn.BatchNorm2d(in_channels // 2),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 2, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels // 2),
            nn.ReLU(inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 2, kernel_size=5, padding=2),
            nn.BatchNorm2d(in_channels // 2),
            nn.ReLU(inplace=True)
        )
        self.out_conv = nn.Sequential(
            nn.Conv2d(in_channels // 2 * 3, out_channels, kernel_size=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)
        out = torch.cat([x1, x2, x3], dim=1)
        return self.out_conv(out)


# 细小水体增强模块
class SmallWaterEnhancementModule(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        # 多尺度特征提取
        self.spatial_pyramid = SpatialPyramidPooling(in_channels, in_channels)

        # 注意力机制，增强细小水体区域
        self.channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, in_channels // 4, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // 4, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

        # 细化特征
        self.refine = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        # 多尺度特征融合
        x = self.spatial_pyramid(x)

        # 应用通道注意力
        attn = self.channel_attn(x)
        x = x * attn

        # 特征细化
        x = self.refine(x)

        return x


# 轻量级水体识别网络 - 修改后的WaterNet
class WaterNet(nn.Module):
    def __init__(self, num_classes=1):
        super().__init__()
        self.backbone = mobilenet_v3_small()
        self.backbone_features = nn.Sequential(*list(self.backbone.features.children())[:-1])
        self.encoder_channels = [16, 24, 40, 48, 96]

        # 添加细小水体增强模块
        self.small_water_enhancer = SmallWaterEnhancementModule(self.encoder_channels[-1])

        self.attention = SelfAttentionModule(self.encoder_channels[-1])

        # 修改解码器输入通道数，考虑跳跃连接的通道数
        self.decoder1 = FeatureFusionModule(self.encoder_channels[-1] * 2, 128)  # 96 + 96 = 192
        self.decoder2 = FeatureFusionModule(128 + self.encoder_channels[-2], 96)
        self.decoder3 = FeatureFusionModule(96 + self.encoder_channels[-3], 64)
        self.decoder4 = FeatureFusionModule(64 + self.encoder_channels[-4], 48)
        self.decoder5 = FeatureFusionModule(48 + self.encoder_channels[-5], 32)

        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.final_conv = nn.Sequential(
            nn.Conv2d(32, 16, 3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, num_classes, 1)
        )

        # 初始化gamma参数
        for m in self.modules():
            if isinstance(m, SelfAttentionModule):
                nn.init.constant_(m.gamma, 0.1)

    def forward(self, x):
        features = []
        for i, layer in enumerate(self.backbone_features):
            x = layer(x)
            if i in [1, 3, 6, 8, 11]:
                features.append(x)

        # 增强对细小水体的识别能力
        x = self.small_water_enhancer(features[-1])
        x = self.attention(x)

        # 修改为直接输入特征
        x = self.decoder1(x, features[-1])
        x = self.decoder2(self.upsample(x), features[-2])
        x = self.decoder3(self.upsample(x), features[-3])
        x = self.decoder4(self.upsample(x), features[-4])
        x = self.decoder5(self.upsample(x), features[-5])
        x = self.upsample(x)

        return self.final_conv(x)


# 改进的损失函数 - 增加数值稳定性
class DiceLoss(nn.Module):
    def __init__(self, smooth=1e-5, eps=1e-7):
        super().__init__()
        self.smooth = smooth
        self.eps = eps  # 防止除零

    def forward(self, inputs, targets):
        inputs = torch.sigmoid(inputs)
        inputs = inputs.view(-1)
        targets = targets.view(-1)

        # 计算交集和并集
        intersection = (inputs * targets).sum()
        union = inputs.sum() + targets.sum()

        # 增加数值稳定性
        dice_score = (2. * intersection + self.smooth) / (union + self.smooth + self.eps)
        return 1 - dice_score


# 自定义数据集 - 增加数据验证
class WaterDataset(Dataset):
    def __init__(self, data_path, mask_path, transform=None, mode='train'):
        self.data_files = sorted([os.path.join(data_path, f) for f in os.listdir(data_path)
                                  if f.endswith(('.png', '.jpg', '.jpeg'))])
        self.mask_files = sorted([os.path.join(mask_path, f) for f in os.listdir(mask_path)
                                  if f.endswith(('.png', '.jpg', '.jpeg'))])
        self.transform = transform
        self.mode = mode

        # 确保数据和标签数量一致
        min_len = min(len(self.data_files), len(self.mask_files))
        self.data_files = self.data_files[:min_len]
        self.mask_files = self.mask_files[:min_len]

        print(f"Loaded {min_len} samples from {data_path} in {mode} mode")

    def __len__(self):
        return len(self.data_files)

    def __getitem__(self, idx):
        try:
            # 读取图像和掩码
            data = np.array(Image.open(self.data_files[idx]).convert('RGB'))
            mask = np.array(Image.open(self.mask_files[idx]))

            # 验证掩码格式
            if len(mask.shape) == 3:
                mask = mask[:, :, 0]

            # 转换为二值掩码，增加健壮性
            mask = ((mask > 127) * 255).astype(np.float32) / 255.0
            # 应用数据增强
            if self.transform:
                aug = self.transform(image=data, mask=mask)
                data = aug['image']
                mask = aug['mask']
                if mask.dim() == 2:
                    mask = mask.unsqueeze(0)

            # 验证数据范围
            if torch.isnan(data).any() or torch.isinf(data).any():
                print(f"Warning: NaN/Inf detected in sample {idx}, data file: {self.data_files[idx]}")
                data = torch.zeros_like(data)

            if torch.isnan(mask).any() or torch.isinf(mask).any():
                print(f"Warning: NaN/Inf detected in mask {idx}, mask file: {self.mask_files[idx]}")
                mask = torch.zeros_like(mask)

            return data, mask
        except Exception as e:
            print(f"Error loading sample {idx}: {e}")
            print(f"Data file: {self.data_files[idx]}, Mask file: {self.mask_files[idx]}")
            return torch.zeros(3, 256, 256), torch.zeros(1, 256, 256)


# 计算评估指标
def calculate_metrics(preds, masks, threshold=0.5):
    preds = torch.sigmoid(preds)
    preds = (preds > threshold).float()

    if preds.dim() == 3:
        preds = preds.unsqueeze(1)
    if masks.dim() == 3:
        masks = masks.unsqueeze(1)

    # 防止除零
    eps = 1e-6

    tp = (preds * masks).sum().float()
    fp = ((1 - masks) * preds).sum().float()
    fn = (masks * (1 - preds)).sum().float()
    tn = ((1 - preds) * (1 - masks)).sum().float()

    intersection = tp
    union = tp + fp + fn
    iou = intersection / (union + eps)
    accuracy = (tp + tn) / (tp + tn + fp + fn + eps)
    precision = tp / (tp + fp + eps)
    recall = tp / (tp + fn + eps)
    f1 = 2 * precision * recall / (precision + recall + eps)

    return {
        'iou': iou,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


# 反标准化函数 - 修复可视化问题
def denormalize(tensor, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]):
    """将标准化的图像转换回原始像素范围"""
    tensor = tensor.clone()  # 避免修改原始张量
    for t, m, s in zip(tensor, mean, std):
        t.mul_(s).add_(m)
    return tensor.clamp(0, 1)


# 可视化训练和验证样本
def visualize_samples(train_loader, val_loader, config):
    os.makedirs(config.analysis_path, exist_ok=True)

    # 可视化训练样本
    train_samples, train_masks = next(iter(train_loader))
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))
    for i in range(5):
        # 反标准化图像
        img = denormalize(train_samples[i])
        axes[0, i].imshow(img.permute(1, 2, 0).cpu().numpy())
        axes[0, i].set_title('Image')
        axes[0, i].axis('off')

        axes[1, i].imshow(train_masks[i].squeeze().cpu().numpy(), cmap='gray')
        axes[1, i].set_title('Mask')
        axes[1, i].axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(config.analysis_path, 'train_samples.png'))
    plt.close()

    # 可视化验证样本
    val_samples, val_masks = next(iter(val_loader))
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))
    for i in range(5):
        # 反标准化图像
        img = denormalize(val_samples[i])
        axes[0, i].imshow(img.permute(1, 2, 0).cpu().numpy())
        axes[0, i].set_title('Image')
        axes[0, i].axis('off')

        axes[1, i].imshow(val_masks[i].squeeze().cpu().numpy(), cmap='gray')
        axes[1, i].set_title('Mask')
        axes[1, i].axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(config.analysis_path, 'val_samples.png'))
    plt.close()


# 分析模型预测结果
def analyze_predictions(model, val_loader, config, epoch):
    os.makedirs(os.path.join(config.analysis_path, f'epoch_{epoch}'), exist_ok=True)

    model.eval()
    with torch.no_grad():
        samples, masks = next(iter(val_loader))
        samples = samples.to(config.device)
        preds = model(samples)
        preds = torch.sigmoid(preds) > 0.5

        for i in range(min(5, len(samples))):
            fig, axes = plt.subplots(1, 3, figsize=(15, 5))

            # 反标准化图像
            img = denormalize(samples[i].cpu())

            axes[0].imshow(img.permute(1, 2, 0).numpy())
            axes[0].set_title('Input Image')
            axes[0].axis('off')

            axes[1].imshow(masks[i].squeeze().cpu().numpy(), cmap='gray')
            axes[1].set_title('Ground Truth')
            axes[1].axis('off')

            axes[2].imshow(preds[i].squeeze().cpu().numpy(), cmap='gray')
            axes[2].set_title('Prediction')
            axes[2].axis('off')

            plt.tight_layout()
            plt.savefig(os.path.join(config.analysis_path, f'epoch_{epoch}', f'prediction_{i}.png'))
            plt.close()


# 训练WaterNet模型
def train_waternet():
    config = Config()
    set_seed(config.seed)
    os.makedirs(config.logs_path, exist_ok=True)
    os.makedirs(config.epoch_outputs_path, exist_ok=True)
    os.makedirs(config.analysis_path, exist_ok=True)

    # 训练数据增强 - 包含更多的变换
    train_transform = A.Compose([
        A.Resize(256, 256),

        # 几何变换 - 保持水体形状
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.Transpose(p=0.5),

        # 弹性变换 - 轻微扭曲但保持语义
        A.ElasticTransform(alpha=1, sigma=50, p=0.2,
                           interpolation=1, border_mode=0),

        # 亮度和对比度调整 - 适应不同光照条件
        A.RandomBrightnessContrast(p=0.5, brightness_limit=(-0.2, 0.2),
                                   contrast_limit=(-0.2, 0.2)),
        A.HueSaturationValue(p=0.3, hue_shift_limit=(-10, 10),
                             sat_shift_limit=(-15, 15), val_shift_limit=(-10, 10)),

        # 模糊和锐化 - 模拟不同水质和成像条件
        A.GaussianBlur(p=0.3, blur_limit=(3, 7)),
        A.Sharpen(p=0.3, alpha=(0.2, 0.5), lightness=(0.5, 1.0)),

        # 标准化
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    # 验证数据增强 - 添加轻微增强，使验证更严格
    val_transform = A.Compose([
        A.Resize(256, 256),
        A.HorizontalFlip(p=0.5),  # 添加轻微的随机性
        A.RandomBrightnessContrast(p=0.3, brightness_limit=(-0.1, 0.1),
                                   contrast_limit=(-0.1, 0.1)),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    try:
        train_dataset = WaterDataset(config.train_data_path, config.train_mask_path, transform=train_transform,
                                     mode='train')
        train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True,
                                  num_workers=config.num_workers, pin_memory=config.pin_memory)

        test_dataset = WaterDataset(config.test_data_path, config.test_mask_path, transform=val_transform, mode='val')
        test_loader = DataLoader(test_dataset, batch_size=config.batch_size, shuffle=False,
                                 num_workers=config.num_workers, pin_memory=config.pin_memory)

        print(f"训练集大小: {len(train_dataset)}, 测试集大小: {len(test_dataset)}")

        # 可视化样本
        visualize_samples(train_loader, test_loader, config)
    except Exception as e:
        print(f"数据加载错误: {e}")
        return

    # 创建模型并移至设备
    model = WaterNet().to(config.device)
    print(f"模型参数数量: {sum(p.numel() for p in model.parameters()):,}")

    # 定义损失函数和优化器
    # 使用组合损失函数
    bce_loss = nn.BCEWithLogitsLoss()
    dice_loss = DiceLoss()

    def combined_loss(preds, targets):
        bce = bce_loss(preds, targets)
        dice = dice_loss(preds, targets)
        return bce + dice

    optimizer = optim.AdamW(model.parameters(), lr=config.lr, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=config.cosine_t_max, T_mult=1, eta_min=config.cosine_eta_min
    )

    # 混合精度训练
    scaler = GradScaler(enabled=config.use_amp)

    # 记录训练历史
    history = {
        'epoch': [], 'train_loss': [], 'val_loss': [],
        'iou': [], 'accuracy': [], 'precision': [], 'recall': [], 'f1': []
    }

    # 最佳模型记录
    best_iou = 0
    best_epoch = 0

    for epoch in range(config.epochs):
        # 训练阶段
        model.train()
        running_loss = 0.0
        batch_count = 0

        # 训练进度条
        train_progress = tqdm(
            enumerate(train_loader),
            total=len(train_loader),
            desc=f'Epoch {epoch + 1}/{config.epochs} [Train]',
            bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}'
        )

        for batch_idx, (inputs, masks) in train_progress:
            inputs = inputs.to(config.device)
            masks = masks.to(config.device)

            optimizer.zero_grad()

            with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                          enabled=config.use_amp, dtype=config.amp_dtype):
                outputs = model(inputs)
                loss = combined_loss(outputs, masks)

            # 检测并处理NaN损失
            if torch.isnan(loss) or torch.isinf(loss):
                print(f"警告: 第{epoch + 1}轮第{batch_idx}批次出现NaN/Inf损失，跳过此批次")

                # 重置梯度缩放器
                if config.use_amp:
                    scaler.update()
                continue

            scaler.scale(loss).backward()

            # 梯度裁剪
            if config.gradient_clip_val > 0:
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=config.gradient_clip_val)

            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            batch_count += 1

            # 更新进度条
            postfix = {'loss': f'{loss.item():.4f}'}
            train_progress.set_postfix(postfix)

            # 释放未使用的显存
            torch.cuda.empty_cache()

        # 计算平均训练损失
        if batch_count > 0:
            avg_train_loss = running_loss / batch_count
        else:
            avg_train_loss = float('nan')
            print(f"警告: 第{epoch + 1}轮没有有效的训练批次")

        # 学习率调度
        scheduler.step()

        # 验证阶段
        model.eval()
        val_metrics = {k: 0.0 for k in ['iou', 'accuracy', 'precision', 'recall', 'f1']}
        running_val_loss = 0.0
        val_batch_count = 0

        # 验证进度条
        val_progress = tqdm(
            enumerate(test_loader),
            total=len(test_loader),
            desc=f'Epoch {epoch + 1}/{config.epochs} [Val]',
            bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}'
        )

        with torch.no_grad():
            for batch_idx, (inputs, masks) in val_progress:
                inputs = inputs.to(config.device)
                masks = masks.to(config.device)

                with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                              enabled=config.use_amp, dtype=config.amp_dtype):
                    outputs = model(inputs)
                    val_loss = combined_loss(outputs, masks)

                # 跳过无效损失
                if torch.isnan(val_loss) or torch.isinf(val_loss):
                    print(f"警告: 第{epoch + 1}轮验证第{batch_idx}批次出现NaN/Inf损失，跳过此批次")
                    continue

                running_val_loss += val_loss.item()
                val_batch_count += 1

                # 计算指标
                batch_metrics = calculate_metrics(outputs, masks)
                for key in val_metrics:
                    val_metrics[key] += batch_metrics[key].item()

                # 更新进度条
                postfix = {'loss': f'{val_loss.item():.4f}', 'iou': f'{batch_metrics["iou"].item():.4f}'}
                val_progress.set_postfix(postfix)

                # 释放未使用的显存
                torch.cuda.empty_cache()

        # 计算平均指标
        if val_batch_count > 0:
            avg_val_loss = running_val_loss / val_batch_count
            for key in val_metrics:
                val_metrics[key] /= val_batch_count
        else:
            avg_val_loss = float('nan')
            val_metrics = {k: float('nan') for k in val_metrics}
            print(f"警告: 第{epoch + 1}轮没有有效的验证批次")

        # 记录训练历史
        history['epoch'].append(epoch + 1)
        history['train_loss'].append(avg_train_loss)
        history['val_loss'].append(avg_val_loss)
        for key in val_metrics:
            history[key].append(val_metrics[key])

        # 分析预测结果
        if (epoch + 1) % 10 == 0:
            analyze_predictions(model, test_loader, config, epoch + 1)

        # 保存当前epoch的模型预测结果
        model.eval()
        save_epoch_outputs(model, test_loader, epoch + 1, config)

        # 打印结果
        current_lr = optimizer.param_groups[0]['lr']
        print(f'\nEpoch {epoch + 1}/{config.epochs} | '
              f'Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f} | '
              f'IoU: {val_metrics["iou"]:.4f} | LR: {current_lr:.6f}')

        # 更新最佳模型
        if val_metrics["iou"] > best_iou:
            best_iou = val_metrics["iou"]
            best_epoch = epoch + 1
            torch.save(model.state_dict(), config.save_path)
            print(f'Best model saved at epoch {best_epoch} with IoU: {best_iou:.4f}')

        # 每n个epoch保存检查点
        if (epoch + 1) % config.checkpoint_every == 0:
            checkpoint_path = os.path.join(config.logs_path, f'checkpoint_epoch_{epoch + 1}.pth')
            torch.save({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'scaler_state_dict': scaler.state_dict(),
                'best_iou': best_iou,
                'history': history
            }, checkpoint_path)
            print(f'Checkpoint saved at epoch {epoch + 1}')

        # 释放未使用的显存
        torch.cuda.empty_cache()

        # 保存训练历史
        pd.DataFrame(history).to_csv(os.path.join(config.logs_path, 'training_history.csv'), index=False)

        # 绘制并保存损失曲线
        plot_and_save_loss_curve(history, config.logs_path)

    print(f'Training complete. Best IoU: {best_iou:.4f} at epoch {best_epoch}')


# 保存每个epoch的模型输出
def save_epoch_outputs(model, dataloader, epoch, config):
    epoch_dir = os.path.join(config.epoch_outputs_path, f'epoch_{epoch:03d}')
    os.makedirs(epoch_dir, exist_ok=True)

    # 始终使用评估模式
    model.eval()

    with torch.no_grad():
        for i, (inputs, masks) in enumerate(dataloader):
            inputs = inputs.to(config.device)

            with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                          enabled=config.use_amp):
                outputs = model(inputs)

            preds = (torch.sigmoid(outputs) > 0.5).float().cpu().numpy()

            for j in range(preds.shape[0]):
                pred_img = Image.fromarray((preds[j, 0] * 255).astype(np.uint8))
                pred_img.save(os.path.join(epoch_dir, f'batch_{i}_sample_{j}.png'))


# 绘制并保存损失曲线
def plot_and_save_loss_curve(history, logs_path):
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    plt.plot(history['epoch'], history['train_loss'], label='Train Loss')
    plt.plot(history['epoch'], history['val_loss'], label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Training and Validation Loss')
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.plot(history['epoch'], history['iou'], label='IoU')
    plt.plot(history['epoch'], history['accuracy'], label='Accuracy')
    plt.plot(history['epoch'], history['precision'], label='Precision')
    plt.plot(history['epoch'], history['recall'], label='Recall')
    plt.plot(history['epoch'], history['f1'], label='F1')
    plt.xlabel('Epoch')
    plt.ylabel('Metrics')
    plt.legend()
    plt.title('Validation Metrics')
    plt.grid(True)

    plt.tight_layout()
    plt.savefig(os.path.join(logs_path, 'training_metrics.png'))
    plt.close()


# 预测函数 - 修改后保持与原图尺寸一致
def predict(checkpoint_path=None):
    config = Config()
    model = WaterNet().to(config.device)

    # 使用指定的检查点或默认保存路径
    if checkpoint_path:
        model_path = checkpoint_path
    else:
        model_path = config.save_path

    if not os.path.exists(model_path):
        print(f"错误: 模型文件 {model_path} 不存在!")
        return

    # 加载模型权重
    try:
        model.load_state_dict(torch.load(model_path, map_location=config.device))
        print(f"成功加载模型: {model_path}")
    except Exception as e:
        print(f"加载模型失败: {e}")
        return

    # 预测时使用推理模式
    model.eval()

    # 预测时仅进行必要的转换
    predict_transform = A.Compose([
        A.Resize(256, 256),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    try:
        data_files = [os.path.join(config.predict_data_path, f)
                      for f in os.listdir(config.predict_data_path) if f.endswith(('.png', '.jpg', '.jpeg'))]
    except Exception as e:
        print(f"错误: 无法读取预测数据目录 {config.predict_data_path}: {e}")
        return

    if not data_files:
        print(f"错误: 在 {config.predict_data_path} 中未找到图像文件!")
        return

    save_dir = "../predict_resultsV3_quantu"
    os.makedirs(save_dir, exist_ok=True)

    # 预测进度条
    progress_bar = tqdm(data_files, desc="Predicting", bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}')

    with torch.no_grad():
        for file_path in progress_bar:
            try:
                img = Image.open(file_path).convert('RGB')
                img_np = np.array(img)
                original_size = img.size  # 记录原始图像尺寸

                img_tensor = predict_transform(image=img_np)['image'].unsqueeze(0).to(config.device)

                with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                              enabled=config.use_amp):
                    pred = model(img_tensor)

                pred = (torch.sigmoid(pred) > 0.5).float().squeeze().cpu().numpy()

                # 调整预测结果的尺寸为原图像尺寸
                pred_img = Image.fromarray((pred * 255).astype(np.uint8))
                pred_img = pred_img.resize(original_size, Image.BILINEAR)  # 使用双线性插值调整尺寸

                save_path = os.path.join(save_dir, os.path.basename(file_path))
                pred_img.save(save_path)

                progress_bar.set_postfix({'Saved': save_path})
            except Exception as e:
                print(f"Error processing {file_path}: {e}")

    print(f'预测完成，结果保存在: {save_dir}')


# 从检查点恢复训练
def resume_training(checkpoint_path):
    config = Config()
    set_seed(config.seed)
    os.makedirs(config.logs_path, exist_ok=True)
    os.makedirs(config.epoch_outputs_path, exist_ok=True)
    os.makedirs(config.analysis_path, exist_ok=True)

    # 训练数据增强 - 包含更多的变换
    train_transform = A.Compose([
        A.Resize(256, 256),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.Transpose(p=0.5),
        A.ElasticTransform(alpha=1, sigma=50, p=0.2,
                           interpolation=1, border_mode=0),
        A.RandomBrightnessContrast(p=0.5, brightness_limit=(-0.2, 0.2),
                                   contrast_limit=(-0.2, 0.2)),
        A.HueSaturationValue(p=0.3, hue_shift_limit=(-10, 10),
                             sat_shift_limit=(-15, 15), val_shift_limit=(-10, 10)),
        A.GaussianBlur(p=0.3, blur_limit=(3, 7)),
        A.Sharpen(p=0.3, alpha=(0.2, 0.5), lightness=(0.5, 1.0)),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    # 验证数据增强 - 添加轻微增强，使验证更严格
    val_transform = A.Compose([
        A.Resize(256, 256),
        A.HorizontalFlip(p=0.5),  # 添加轻微的随机性
        A.RandomBrightnessContrast(p=0.3, brightness_limit=(-0.1, 0.1),
                                   contrast_limit=(-0.1, 0.1)),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    try:
        train_dataset = WaterDataset(config.train_data_path, config.train_mask_path, transform=train_transform,
                                     mode='train')
        train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True,
                                  num_workers=config.num_workers, pin_memory=config.pin_memory)

        test_dataset = WaterDataset(config.test_data_path, config.test_mask_path, transform=val_transform, mode='val')
        test_loader = DataLoader(test_dataset, batch_size=config.batch_size, shuffle=False,
                                 num_workers=config.num_workers, pin_memory=config.pin_memory)

        print(f"训练集大小: {len(train_dataset)}, 测试集大小: {len(test_dataset)}")

        # 可视化样本
        visualize_samples(train_loader, test_loader, config)
    except Exception as e:
        print(f"数据加载错误: {e}")
        return

    # 创建模型并移至设备
    model = WaterNet().to(config.device)
    print(f"模型参数数量: {sum(p.numel() for p in model.parameters()):,}")

    # 定义损失函数和优化器
    bce_loss = nn.BCEWithLogitsLoss()
    dice_loss = DiceLoss()

    def combined_loss(preds, targets):
        bce = bce_loss(preds, targets)
        dice = dice_loss(preds, targets)
        return bce + dice

    optimizer = optim.AdamW(model.parameters(), lr=config.lr, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=config.cosine_t_max, T_mult=1, eta_min=config.cosine_eta_min
    )

    # 混合精度训练
    scaler = GradScaler(enabled=config.use_amp)

    # 记录训练历史
    history = {
        'epoch': [], 'train_loss': [], 'val_loss': [],
        'iou': [], 'accuracy': [], 'precision': [], 'recall': [], 'f1': []
    }

    # 最佳模型记录
    best_iou = 0
    best_epoch = 0

    # 加载检查点
    try:
        checkpoint = torch.load(checkpoint_path, map_location=config.device)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        scaler.load_state_dict(checkpoint['scaler_state_dict'])
        start_epoch = checkpoint['epoch']
        best_iou = checkpoint['best_iou']
        history = checkpoint['history']

        print(f"从检查点 {checkpoint_path} 恢复训练，当前为第 {start_epoch} 轮")
    except Exception as e:
        print(f"加载检查点失败: {e}")
        print("从第1轮开始全新训练")
        start_epoch = 1

    for epoch in range(start_epoch, config.epochs + 1):
        # 训练阶段
        model.train()
        running_loss = 0.0
        batch_count = 0

        # 训练进度条
        train_progress = tqdm(
            enumerate(train_loader),
            total=len(train_loader),
            desc=f'Epoch {epoch}/{config.epochs} [Train]',
            bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}'
        )

        for batch_idx, (inputs, masks) in train_progress:
            inputs = inputs.to(config.device)
            masks = masks.to(config.device)

            optimizer.zero_grad()

            with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                          enabled=config.use_amp, dtype=config.amp_dtype):
                outputs = model(inputs)
                loss = combined_loss(outputs, masks)

            # 检测并处理NaN损失
            if torch.isnan(loss) or torch.isinf(loss):
                print(f"警告: 第{epoch}轮第{batch_idx}批次出现NaN/Inf损失，跳过此批次")

                # 重置梯度缩放器
                if config.use_amp:
                    scaler.update()
                continue

            scaler.scale(loss).backward()

            # 梯度裁剪
            if config.gradient_clip_val > 0:
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=config.gradient_clip_val)

            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            batch_count += 1

            # 更新进度条
            postfix = {'loss': f'{loss.item():.4f}'}
            train_progress.set_postfix(postfix)

            # 释放未使用的显存
            torch.cuda.empty_cache()

        # 计算平均训练损失
        if batch_count > 0:
            avg_train_loss = running_loss / batch_count
        else:
            avg_train_loss = float('nan')
            print(f"警告: 第{epoch}轮没有有效的训练批次")

        # 学习率调度
        scheduler.step()

        # 验证阶段
        model.eval()
        val_metrics = {k: 0.0 for k in ['iou', 'accuracy', 'precision', 'recall', 'f1']}
        running_val_loss = 0.0
        val_batch_count = 0

        # 验证进度条
        val_progress = tqdm(
            enumerate(test_loader),
            total=len(test_loader),
            desc=f'Epoch {epoch}/{config.epochs} [Val]',
            bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}'
        )

        with torch.no_grad():
            for batch_idx, (inputs, masks) in val_progress:
                inputs = inputs.to(config.device)
                masks = masks.to(config.device)

                with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                              enabled=config.use_amp, dtype=config.amp_dtype):
                    outputs = model(inputs)
                    val_loss = combined_loss(outputs, masks)

                # 跳过无效损失
                if torch.isnan(val_loss) or torch.isinf(val_loss):
                    print(f"警告: 第{epoch}轮验证第{batch_idx}批次出现NaN/Inf损失，跳过此批次")
                    continue

                running_val_loss += val_loss.item()
                val_batch_count += 1

                # 计算指标
                batch_metrics = calculate_metrics(outputs, masks)
                for key in val_metrics:
                    val_metrics[key] += batch_metrics[key].item()

                # 更新进度条
                postfix = {'loss': f'{val_loss.item():.4f}', 'iou': f'{batch_metrics["iou"].item():.4f}'}
                val_progress.set_postfix(postfix)

                # 释放未使用的显存
                torch.cuda.empty_cache()

        # 计算平均指标
        if val_batch_count > 0:
            avg_val_loss = running_val_loss / val_batch_count
            for key in val_metrics:
                val_metrics[key] /= val_batch_count
        else:
            avg_val_loss = float('nan')
            val_metrics = {k: float('nan') for k in val_metrics}
            print(f"警告: 第{epoch}轮没有有效的验证批次")

        # 记录训练历史
        history['epoch'].append(epoch)
        history['train_loss'].append(avg_train_loss)
        history['val_loss'].append(avg_val_loss)
        for key in val_metrics:
            history[key].append(val_metrics[key])

        # 分析预测结果
        if epoch % 10 == 0:
            analyze_predictions(model, test_loader, config, epoch)

        # 保存当前epoch的模型预测结果
        model.eval()
        save_epoch_outputs(model, test_loader, epoch, config)

        # 打印结果
        current_lr = optimizer.param_groups[0]['lr']
        print(f'\nEpoch {epoch}/{config.epochs} | '
              f'Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f} | '
              f'IoU: {val_metrics["iou"]:.4f} | LR: {current_lr:.6f}')

        # 更新最佳模型
        if val_metrics["iou"] > best_iou:
            best_iou = val_metrics["iou"]
            best_epoch = epoch
            torch.save(model.state_dict(), config.save_path)
            print(f'Best model saved at epoch {best_epoch} with IoU: {best_iou:.4f}')

        # 每n个epoch保存检查点
        if epoch % config.checkpoint_every == 0:
            checkpoint_path = os.path.join(config.logs_path, f'checkpoint_epoch_{epoch}.pth')
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'scaler_state_dict': scaler.state_dict(),
                'best_iou': best_iou,
                'history': history
            }, checkpoint_path)
            print(f'Checkpoint saved at epoch {epoch}')

        # 释放未使用的显存
        torch.cuda.empty_cache()

        # 保存训练历史
        pd.DataFrame(history).to_csv(os.path.join(config.logs_path, 'training_history.csv'), index=False)

        # 绘制并保存损失曲线
        plot_and_save_loss_curve(history, config.logs_path)

    print(f'Training complete. Best IoU: {best_iou:.4f} at epoch {best_epoch}')


# 主函数
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='WaterNet水体识别网络')
    parser.add_argument('--mode', type=str, default='train', choices=['train', 'predict', 'resume'],
                        help='运行模式：train-训练模型，predict-预测，resume-从检查点恢复训练')
    parser.add_argument('--checkpoint', type=str, default=None,
                        help='检查点路径，用于恢复训练或预测')

    args = parser.parse_args()

    predict(args.checkpoint)

    # if args.mode == 'train':
    #
    # elif args.mode == 'predict':
    #     predict(args.checkpoint)
    # elif args.mode == 'resume':
    #     if args.checkpoint is None:
    #         print("错误: 恢复训练需要指定检查点路径")
    #     else:
    #         resume_training(args.checkpoint)