import warnings
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as F
from PIL import Image
import numpy as np
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torch.amp import autocast, GradScaler
from tqdm import tqdm
import pandas as pd
import matplotlib.pyplot as plt
import random
import torchvision.models as models

# 禁用albumentations的版本检查
os.environ['ALBUMENTATIONS_DISABLE_VERSION_CHECK'] = '1'
# 过滤不必要的警告
warnings.filterwarnings("ignore", category=UserWarning, module="albumentations")
warnings.filterwarnings("ignore", category=FutureWarning, module="torch")

# 设置PyTorch数值稳定性选项
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.deterministic = False


# 配置参数
class Config:
    # 数据路径
    train_data_path = r"E:\shuju_S2\dset-s2\yangben\xunlian\shujuji"
    train_mask_path = r"E:\shuju_S2\dset-s2\yangben\xunlian\yangbenji"
    test_data_path = r"E:\shuju_S2\dset-s2\yangben\ceshi\shujuji"
    test_mask_path = r"E:\shuju_S2\dset-s2\yangben\ceshi\yangbenji"
    predict_data_path = r"E:\shuju_S2\dset-s2\shuchushuju_png"

    # 训练参数
    batch_size = 16
    epochs = 200
    lr = 0.001
    min_lr = 1e-6  # 最小学习率
    num_workers = 0
    pin_memory = True
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    use_amp = True
    amp_dtype = torch.float16  # 混合精度类型

    # 学习率调度器参数
    cosine_t_max = 20
    cosine_eta_min = 1e-6

    # 模型保存路径
    save_path = r"E:\shuju_S2\消融实验\主干网络\waternet_resnet.pth"

    # 日志和输出保存路径
    logs_path = r"E:\shuju_S2\消融实验\主干网络\training_logs_resnet"
    epoch_outputs_path = r"E:\shuju_S2\消融实验\主干网络\epoch_outputs_resnet"
    analysis_path = r"E:\shuju_S2\消融实验\主干网络\training_analysis_resnet"

    # 模型和训练配置
    gradient_clip_val = 1.0  # 梯度裁剪阈值
    checkpoint_every = 10  # 每n个epoch保存一次检查点
    seed = 42  # 随机种子


# 设置随机种子以确保可重复性
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# 自注意力模块 - 数值稳定性改进
class SelfAttentionModule(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.query = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.key = nn.Conv2d(in_channels, in_channels // 8, 1)
        self.value = nn.Conv2d(in_channels, in_channels, 1)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        b, c, h, w = x.size()
        q = self.query(x).view(b, -1, h * w).permute(0, 2, 1)  # [B, N, C]
        k = self.key(x).view(b, -1, h * w)  # [B, C, N]
        v = self.value(x).view(b, -1, h * w)  # [B, C, N]

        # 缩放点积注意力，提高数值稳定性
        attention = torch.bmm(q, k) / (q.size(-1) ** 0.5)
        attention = self.softmax(attention)

        out = torch.bmm(v, attention.permute(0, 2, 1)).view(b, c, h, w)
        return self.gamma * out + x


# 特征融合模块
class FeatureFusionModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x1, x2):
        if x1.size()[2:] != x2.size()[2:]:
            x2 = F.interpolate(x2, size=x1.size()[2:], mode='bilinear', align_corners=False)
        return self.conv(torch.cat([x1, x2], dim=1))


# 空间金字塔池化模块 - 帮助识别不同尺度的水体
class SpatialPyramidPooling(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 2, kernel_size=1),
            nn.BatchNorm2d(in_channels // 2),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 2, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels // 2),
            nn.ReLU(inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // 2, kernel_size=5, padding=2),
            nn.BatchNorm2d(in_channels // 2),
            nn.ReLU(inplace=True)
        )
        self.out_conv = nn.Sequential(
            nn.Conv2d(in_channels // 2 * 3, out_channels, kernel_size=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)
        out = torch.cat([x1, x2, x3], dim=1)
        return self.out_conv(out)


# 细小水体增强模块
class SmallWaterEnhancementModule(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        # 多尺度特征提取
        self.spatial_pyramid = SpatialPyramidPooling(in_channels, in_channels)

        # 注意力机制，增强细小水体区域
        self.channel_attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, in_channels // 4, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // 4, in_channels, kernel_size=1),
            nn.Sigmoid()
        )

        # 细化特征
        self.refine = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        # 多尺度特征融合
        x = self.spatial_pyramid(x)

        # 应用通道注意力
        attn = self.channel_attn(x)
        x = x * attn

        # 特征细化
        x = self.refine(x)

        return x


# 水体识别网络 - 使用ResNet18作为编码器
class WaterNet(nn.Module):
    def __init__(self, num_classes=1):
        super().__init__()
        # 使用ResNet18作为编码器
        self.backbone = models.resnet18(pretrained=False)
        self.backbone.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)

        # 调整ResNet的特征提取层，匹配通道数
        self.channel_adapter = nn.ModuleList([
            nn.Conv2d(64, 16, 1),  # layer1输出通道64 -> 16
            nn.Conv2d(128, 24, 1),  # layer2输出通道128 -> 24
            nn.Conv2d(256, 40, 1),  # layer3输出通道256 -> 40
            nn.Conv2d(512, 48, 1),  # layer4输出通道512 -> 48
            nn.Conv2d(512, 96, 1),  # layer4输出通道512 -> 96
        ])

        # 保留原解码器和其他模块
        self.small_water_enhancer = SmallWaterEnhancementModule(96)
        self.attention = SelfAttentionModule(96)

        self.decoder1 = FeatureFusionModule(96 * 2, 128)  # 96（增强后） + 96（原特征）
        self.decoder2 = FeatureFusionModule(128 + 48, 96)  # 128 + layer4的48通道
        self.decoder3 = FeatureFusionModule(96 + 40, 64)  # 96 + layer3的40通道
        self.decoder4 = FeatureFusionModule(64 + 24, 48)  # 64 + layer2的24通道
        self.decoder5 = FeatureFusionModule(48 + 16, 32)  # 48 + layer1的16通道

        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.final_conv = nn.Sequential(
            nn.Conv2d(32, 16, 3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, num_classes, 1)
        )

        # 初始化gamma参数
        for m in self.modules():
            if isinstance(m, SelfAttentionModule):
                nn.init.constant_(m.gamma, 0.1)

    def forward(self, x):
        features = []
        x = self.backbone.conv1(x)
        x = self.backbone.bn1(x)
        x = self.backbone.relu(x)
        x = self.backbone.maxpool(x)  # 尺寸: (64, 64)

        # layer1
        x = self.backbone.layer1(x)  # 输出通道64
        features.append(self.channel_adapter[0](x))  # 索引0: 64->16

        # layer2
        x = self.backbone.layer2(x)  # 输出通道128
        features.append(self.channel_adapter[1](x))  # 索引1: 128->24

        # layer3
        x = self.backbone.layer3(x)  # 输出通道256
        features.append(self.channel_adapter[2](x))  # 索引2: 256->40

        # layer4
        x = self.backbone.layer4(x)  # 输出通道512
        final_feature = self.channel_adapter[4](x)  # 索引4: 512->96（作为最终特征）
        features.append(self.channel_adapter[3](x))  # 索引3: 512->48（用于解码器）

        # 增强模块和注意力模块
        x = self.small_water_enhancer(final_feature)
        x = self.attention(x)

        # 解码器部分
        x = self.decoder1(x, final_feature)  # 输入: 96+96=192 -> 128通道
        x = self.upsample(x)  # 尺寸16x16

        x = self.decoder2(x, features[3])  # features[3]是layer4的48通道（索引3）
        x = self.upsample(x)  # 尺寸32x32

        x = self.decoder3(x, features[2])  # features[2]是layer3的40通道（索引2）
        x = self.upsample(x)  # 尺寸64x64

        x = self.decoder4(x, features[1])  # features[1]是layer2的24通道（索引1）
        x = self.upsample(x)  # 尺寸128x128

        x = self.decoder5(x, features[0])  # features[0]是layer1的16通道（索引0）
        x = self.upsample(x)  # 尺寸256x256

        return self.final_conv(x)


# 改进的损失函数 - 增加数值稳定性
class DiceLoss(nn.Module):
    def __init__(self, smooth=1e-5, eps=1e-7):
        super().__init__()
        self.smooth = smooth
        self.eps = eps  # 防止除零

    def forward(self, inputs, targets):
        inputs = torch.sigmoid(inputs)
        inputs = inputs.view(-1)
        targets = targets.view(-1)

        # 计算交集和并集
        intersection = (inputs * targets).sum()
        union = inputs.sum() + targets.sum()

        # 增加数值稳定性
        dice_score = (2. * intersection + self.smooth) / (union + self.smooth + self.eps)
        return 1 - dice_score


# 自定义数据集 - 增加数据验证
class WaterDataset(Dataset):
    def __init__(self, data_path, mask_path, transform=None, mode='train'):
        self.data_files = sorted([os.path.join(data_path, f) for f in os.listdir(data_path)
                                  if f.endswith(('.png', '.jpg', '.jpeg'))])
        self.mask_files = sorted([os.path.join(mask_path, f) for f in os.listdir(mask_path)
                                  if f.endswith(('.png', '.jpg', '.jpeg'))])
        self.transform = transform
        self.mode = mode

        # 确保数据和标签数量一致
        min_len = min(len(self.data_files), len(self.mask_files))
        self.data_files = self.data_files[:min_len]
        self.mask_files = self.mask_files[:min_len]

        print(f"Loaded {min_len} samples from {data_path} in {mode} mode")

    def __len__(self):
        return len(self.data_files)

    def __getitem__(self, idx):
        try:
            # 读取图像和掩码
            data = np.array(Image.open(self.data_files[idx]).convert('RGB'))
            mask = np.array(Image.open(self.mask_files[idx]))

            # 验证掩码格式
            if len(mask.shape) == 3:
                mask = mask[:, :, 0]

            # 转换为二值掩码，增加健壮性
            mask = ((mask > 127) * 255).astype(np.float32) / 255.0
            # 应用数据增强
            if self.transform:
                aug = self.transform(image=data, mask=mask)
                data = aug['image']
                mask = aug['mask']
                if mask.dim() == 2:
                    mask = mask.unsqueeze(0)

            # 验证数据范围
            if torch.isnan(data).any() or torch.isinf(data).any():
                print(f"Warning: NaN/Inf detected in sample {idx}, data file: {self.data_files[idx]}")
                data = torch.zeros_like(data)

            if torch.isnan(mask).any() or torch.isinf(mask).any():
                print(f"Warning: NaN/Inf detected in mask {idx}, mask file: {self.mask_files[idx]}")
                mask = torch.zeros_like(mask)

            return data, mask
        except Exception as e:
            print(f"Error loading sample {idx}: {e}")
            print(f"Data file: {self.data_files[idx]}, Mask file: {self.mask_files[idx]}")
            return torch.zeros(3, 256, 256), torch.zeros(1, 256, 256)


# 计算评估指标
def calculate_metrics(preds, masks, threshold=0.5):
    preds = torch.sigmoid(preds)
    preds = (preds > threshold).float()

    if preds.dim() == 3:
        preds = preds.unsqueeze(1)
    if masks.dim() == 3:
        masks = masks.unsqueeze(1)

    # 防止除零
    eps = 1e-6

    tp = (preds * masks).sum().float()
    fp = ((1 - masks) * preds).sum().float()
    fn = (masks * (1 - preds)).sum().float()
    tn = ((1 - preds) * (1 - masks)).sum().float()

    intersection = tp
    union = tp + fp + fn
    iou = intersection / (union + eps)
    accuracy = (tp + tn) / (tp + tn + fp + fn + eps)
    precision = tp / (tp + fp + eps)
    recall = tp / (tp + fn + eps)
    f1 = 2 * precision * recall / (precision + recall + eps)

    return {
        'iou': iou,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


# 反标准化函数 - 修复可视化问题
def denormalize(tensor, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]):
    """将标准化的图像转换回原始像素范围"""
    tensor = tensor.clone()  # 避免修改原始张量
    for t, m, s in zip(tensor, mean, std):
        t.mul_(s).add_(m)
    return tensor.clamp(0, 1)


# 可视化训练和验证样本
def visualize_samples(train_loader, val_loader, config):
    os.makedirs(config.analysis_path, exist_ok=True)

    # 可视化训练样本
    train_samples, train_masks = next(iter(train_loader))
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))
    for i in range(5):
        # 反标准化图像
        img = denormalize(train_samples[i])
        axes[0, i].imshow(img.permute(1, 2, 0).cpu().numpy())
        axes[0, i].set_title('Image')
        axes[0, i].axis('off')

        axes[1, i].imshow(train_masks[i].squeeze().cpu().numpy(), cmap='gray')
        axes[1, i].set_title('Mask')
        axes[1, i].axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(config.analysis_path, 'train_samples.png'))
    plt.close()

    # 可视化验证样本
    val_samples, val_masks = next(iter(val_loader))
    fig, axes = plt.subplots(2, 5, figsize=(15, 6))
    for i in range(5):
        # 反标准化图像
        img = denormalize(val_samples[i])
        axes[0, i].imshow(img.permute(1, 2, 0).cpu().numpy())
        axes[0, i].set_title('Image')
        axes[0, i].axis('off')

        axes[1, i].imshow(val_masks[i].squeeze().cpu().numpy(), cmap='gray')
        axes[1, i].set_title('Mask')
        axes[1, i].axis('off')
    plt.tight_layout()
    plt.savefig(os.path.join(config.analysis_path, 'val_samples.png'))
    plt.close()


# 分析模型预测结果
def analyze_predictions(model, val_loader, config, epoch):
    os.makedirs(os.path.join(config.analysis_path, f'epoch_{epoch}'), exist_ok=True)

    model.eval()
    with torch.no_grad():
        samples, masks = next(iter(val_loader))
        samples = samples.to(config.device)
        preds = model(samples)
        preds = torch.sigmoid(preds) > 0.5

        for i in range(min(5, len(samples))):
            fig, axes = plt.subplots(1, 3, figsize=(15, 5))

            # 反标准化图像
            img = denormalize(samples[i].cpu())

            axes[0].imshow(img.permute(1, 2, 0).numpy())
            axes[0].set_title('Input Image')
            axes[0].axis('off')

            axes[1].imshow(masks[i].squeeze().cpu().numpy(), cmap='gray')
            axes[1].set_title('Ground Truth')
            axes[1].axis('off')

            axes[2].imshow(preds[i].squeeze().cpu().numpy(), cmap='gray')
            axes[2].set_title('Prediction')
            axes[2].axis('off')

            plt.tight_layout()
            plt.savefig(os.path.join(config.analysis_path, f'epoch_{epoch}', f'prediction_{i}.png'))
            plt.close()


# 训练WaterNet模型
def train_waternet():
    config = Config()
    set_seed(config.seed)
    os.makedirs(config.logs_path, exist_ok=True)
    os.makedirs(config.epoch_outputs_path, exist_ok=True)
    os.makedirs(config.analysis_path, exist_ok=True)

    # 训练数据增强 - 包含更多的变换
    train_transform = A.Compose([
        A.Resize(256, 256),

        # 几何变换 - 保持水体形状
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.RandomRotate90(p=0.5),
        A.Transpose(p=0.5),

        # 弹性变换 - 轻微扭曲但保持语义
        A.ElasticTransform(alpha=1, sigma=50, p=0.2,
                           interpolation=1, border_mode=0),

        # 亮度和对比度调整 - 适应不同光照条件
        A.RandomBrightnessContrast(p=0.5, brightness_limit=(-0.2, 0.2),
                                   contrast_limit=(-0.2, 0.2)),
        A.HueSaturationValue(p=0.3, hue_shift_limit=(-10, 10),
                             sat_shift_limit=(-15, 15), val_shift_limit=(-10, 10)),

        # 模糊和锐化 - 模拟不同水质和成像条件
        A.GaussianBlur(p=0.3, blur_limit=(3, 7)),
        A.Sharpen(p=0.3, alpha=(0.2, 0.5), lightness=(0.5, 1.0)),

        # 标准化
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    # 验证数据增强 - 添加轻微增强，使验证更严格
    val_transform = A.Compose([
        A.Resize(256, 256),
        A.HorizontalFlip(p=0.5),  # 添加轻微的随机性
        A.RandomBrightnessContrast(p=0.3, brightness_limit=(-0.1, 0.1),
                                   contrast_limit=(-0.1, 0.1)),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    try:
        train_dataset = WaterDataset(config.train_data_path, config.train_mask_path, transform=train_transform,
                                     mode='train')
        train_loader = DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True,
                                  num_workers=config.num_workers, pin_memory=config.pin_memory)

        test_dataset = WaterDataset(config.test_data_path, config.test_mask_path, transform=val_transform, mode='val')
        test_loader = DataLoader(test_dataset, batch_size=config.batch_size, shuffle=False,
                                 num_workers=config.num_workers, pin_memory=config.pin_memory)

        print(f"训练集大小: {len(train_dataset)}, 测试集大小: {len(test_dataset)}")

        # 可视化样本
        visualize_samples(train_loader, test_loader, config)
    except Exception as e:
        print(f"数据加载错误: {e}")
        return

    # 创建模型并移至设备
    model = WaterNet().to(config.device)
    print(f"模型参数数量: {sum(p.numel() for p in model.parameters()):,}")

    # 定义损失函数和优化器
    # 使用组合损失函数
    bce_loss = nn.BCEWithLogitsLoss()
    dice_loss = DiceLoss()

    def combined_loss(preds, targets):
        bce = bce_loss(preds, targets)
        dice = dice_loss(preds, targets)
        return bce + dice

    optimizer = optim.AdamW(model.parameters(), lr=config.lr, weight_decay=1e-5)
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=config.cosine_t_max, T_mult=1, eta_min=config.cosine_eta_min
    )

    # 混合精度训练
    scaler = GradScaler(enabled=config.use_amp)

    # 记录训练历史
    history = {
        'epoch': [], 'train_loss': [], 'val_loss': [],
        'iou': [], 'accuracy': [], 'precision': [], 'recall': [], 'f1': []
    }

    # 最佳模型记录
    best_iou = 0
    best_epoch = 0

    for epoch in range(config.epochs):
        # 训练阶段
        model.train()
        running_loss = 0.0
        batch_count = 0

        # 训练进度条
        train_progress = tqdm(
            enumerate(train_loader),
            total=len(train_loader),
            desc=f'Epoch {epoch + 1}/{config.epochs} [Train]',
            bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}'
        )

        for batch_idx, (inputs, masks) in train_progress:
            inputs = inputs.to(config.device)
            masks = masks.to(config.device)

            optimizer.zero_grad()

            with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                          enabled=config.use_amp, dtype=config.amp_dtype):
                outputs = model(inputs)
                loss = combined_loss(outputs, masks)

            # 检测并处理NaN损失
            if torch.isnan(loss) or torch.isinf(loss):
                print(f"警告: 第{epoch + 1}轮第{batch_idx}批次出现NaN/Inf损失，跳过此批次")

                # 重置梯度缩放器
                if config.use_amp:
                    scaler.update()
                continue

            scaler.scale(loss).backward()

            # 梯度裁剪
            if config.gradient_clip_val > 0:
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), max_norm=config.gradient_clip_val)

            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            batch_count += 1

            # 更新进度条
            postfix = {'loss': f'{loss.item():.4f}'}
            train_progress.set_postfix(postfix)

            # 释放未使用的显存
            torch.cuda.empty_cache()

        # 计算平均训练损失
        if batch_count > 0:
            avg_train_loss = running_loss / batch_count
        else:
            avg_train_loss = float('nan')
            print(f"警告: 第{epoch + 1}轮没有有效的训练批次")

        # 学习率调度
        scheduler.step()

        # 验证阶段
        model.eval()
        val_metrics = {k: 0.0 for k in ['iou', 'accuracy', 'precision', 'recall', 'f1']}
        running_val_loss = 0.0
        val_batch_count = 0

        # 验证进度条
        val_progress = tqdm(
            enumerate(test_loader),
            total=len(test_loader),
            desc=f'Epoch {epoch + 1}/{config.epochs} [Val]',
            bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}'
        )

        with torch.no_grad():
            for batch_idx, (inputs, masks) in val_progress:
                inputs = inputs.to(config.device)
                masks = masks.to(config.device)

                with autocast(device_type='cuda' if 'cuda' in str(config.device) else 'cpu',
                              enabled=config.use_amp, dtype=config.amp_dtype):
                    outputs = model(inputs)
                    val_loss = combined_loss(outputs, masks)

                # 跳过无效损失
                if torch.isnan(val_loss) or torch.isinf(val_loss):
                    print(f"警告: 第{epoch + 1}轮验证第{batch_idx}批次出现NaN/Inf损失，跳过此批次")
                    continue

                running_val_loss += val_loss.item()
                val_batch_count += 1

                # 计算指标
                batch_metrics = calculate_metrics(outputs, masks)
                for key in val_metrics:
                    val_metrics[key] += batch_metrics[key].item()

                # 更新进度条
                postfix = {'loss': f'{val_loss.item():.4f}', 'iou': f'{batch_metrics["iou"].item():.4f}'}
                val_progress.set_postfix(postfix)

                # 释放未使用的显存
                torch.cuda.empty_cache()

        # 计算平均指标
        if val_batch_count > 0:
            avg_val_loss = running_val_loss / val_batch_count
            for key in val_metrics:
                val_metrics[key] /= val_batch_count
        else:
            avg_val_loss = float('nan')
            val_metrics = {k: float('nan') for k in val_metrics}
            print(f"警告: 第{epoch + 1}轮没有有效的验证批次")

        # 记录训练历史
        history['epoch'].append(epoch + 1)
        history['train_loss'].append(avg_train_loss)
        history['val_loss'].append(avg_val_loss)
        for key in val_metrics:
            history[key].append(val_metrics[key])

        # 分析预测结果
        if (epoch + 1) % 10 == 0:
            analyze_predictions(model, test_loader, config, epoch + 1)

        # 保存当前epoch的模型预测结果
        save_epoch_outputs(model, test_loader, epoch + 1, config)

        # 打印结果
        current_lr = optimizer.param_groups[0]['lr']
        print(f'\nEpoch {epoch + 1}/{config.epochs} | '
              f'Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f} | '
              f'IoU: {val_metrics["iou"]:.4f} | LR: {current_lr:.6f}')

        # 更新最佳模型
        if val_metrics["iou"] > best_iou:
            best_iou = val_metrics["iou"]
            best_epoch = epoch + 1
            torch.save(model.state_dict(), config.save_path)
            print(f'Best model saved at epoch {best_epoch} with IoU: {best_iou:.4f}')

        # 每n个epoch保存检查点
        if (epoch + 1) % config.checkpoint_every == 0:
            checkpoint_path = os.path.join(config.logs_path, f'checkpoint_epoch_{epoch + 1}.pth')
            torch.save({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'scaler_state_dict': scaler.state_dict(),
                'best_iou': best_iou,
                'history': history
            }, checkpoint_path)
            print(f'Checkpoint saved at epoch {epoch + 1}')

        # 释放未使用的显存
        torch.cuda.empty_cache()

        # 保存训练历史
        pd.DataFrame(history).to_csv(os.path.join(config.logs_path, 'training_history.csv'), index=False)
        # 绘制训练曲线
        plot_and_save_loss_curve(history, config.logs_path)

    print(f'\n训练完成! 最佳模型在第 {best_epoch} 轮，IoU: {best_iou:.4f}')
    print(f'最佳模型已保存至: {config.save_path}')

    # 加载最佳模型并进行最终评估
    model.load_state_dict(torch.load(config.save_path))
    model.eval()
    final_metrics = evaluate_model(model, test_loader, config)
    print('\n最终评估结果:')
    for key, value in final_metrics.items():
        print(f'{key.capitalize()}: {value:.4f}')

    # 保存最终预测结果
    save_final_predictions(model, test_loader, config)


# 保存每个epoch的模型输出结果
def save_epoch_outputs(model, data_loader, epoch, config):
    os.makedirs(os.path.join(config.epoch_outputs_path, f'epoch_{epoch}'), exist_ok=True)
    model.eval()

    with torch.no_grad():
        for i, (inputs, masks) in enumerate(data_loader):
            inputs = inputs.to(config.device)
            outputs = model(inputs)
            outputs = torch.sigmoid(outputs) > 0.5

            for j in range(len(inputs)):
                # 保存原始图像
                img = denormalize(inputs[j].cpu())
                img_np = img.permute(1, 2, 0).numpy() * 255
                img_pil = Image.fromarray(img_np.astype(np.uint8))
                img_pil.save(os.path.join(config.epoch_outputs_path, f'epoch_{epoch}', f'img_{i}_{j}.png'))

                # 保存真实掩码
                mask_np = masks[j].squeeze().cpu().numpy() * 255
                mask_pil = Image.fromarray(mask_np.astype(np.uint8), mode='L')
                mask_pil.save(os.path.join(config.epoch_outputs_path, f'epoch_{epoch}', f'mask_{i}_{j}.png'))

                # 保存预测结果
                pred_np = outputs[j].squeeze().cpu().numpy() * 255
                pred_pil = Image.fromarray(pred_np.astype(np.uint8), mode='L')
                pred_pil.save(os.path.join(config.epoch_outputs_path, f'epoch_{epoch}', f'{i}_{j}.png'))

            # 只保存前几个批次的结果
            if i >= 2:
                break


# 绘制训练历史曲线
def plot_and_save_loss_curve(history, logs_path):
    plt.figure(figsize=(12, 5))

    plt.plot(history['epoch'], history['train_loss'], label='Train Loss')
    plt.plot(history['epoch'], history['val_loss'], label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Training and Validation Loss')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(logs_path, 'loss.png'))
    plt.close()


    plt.figure(figsize=(12, 5))
    plt.plot(history['epoch'], history['iou'], label='IoU')
    plt.plot(history['epoch'], history['accuracy'], label='Accuracy')
    plt.plot(history['epoch'], history['f1'], label='F1')
    plt.xlabel('Epoch')
    plt.ylabel('Metrics')
    plt.legend()
    plt.title('Validation Metrics')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(logs_path, '精度.png'))
    plt.close()


# 评估模型
def evaluate_model(model, data_loader, config):
    model.eval()
    metrics = {k: 0.0 for k in ['iou', 'accuracy', 'precision', 'recall', 'f1']}
    total_samples = 0

    with torch.no_grad():
        for inputs, masks in data_loader:
            inputs = inputs.to(config.device)
            masks = masks.to(config.device)

            outputs = model(inputs)
            batch_metrics = calculate_metrics(outputs, masks)

            batch_size = inputs.size(0)
            for key in metrics:
                metrics[key] += batch_metrics[key].item() * batch_size
            total_samples += batch_size

    for key in metrics:
        metrics[key] /= total_samples

    return metrics


# 保存最终预测结果
def save_final_predictions(model, data_loader, config):
    os.makedirs(os.path.join(config.analysis_path, 'final_predictions'), exist_ok=True)
    model.eval()

    with torch.no_grad():
        for i, (inputs, masks) in enumerate(data_loader):
            inputs = inputs.to(config.device)
            outputs = model(inputs)
            outputs = torch.sigmoid(outputs) > 0.5

            for j in range(len(inputs)):
                fig, axes = plt.subplots(1, 3, figsize=(15, 5))

                # 原始图像
                img = denormalize(inputs[j].cpu())
                axes[0].imshow(img.permute(1, 2, 0).numpy())
                axes[0].set_title('Input Image')
                axes[0].axis('off')

                # 真实掩码
                axes[1].imshow(masks[j].squeeze().cpu().numpy(), cmap='gray')
                axes[1].set_title('Ground Truth')
                axes[1].axis('off')

                # 预测结果
                axes[2].imshow(outputs[j].squeeze().cpu().numpy(), cmap='gray')
                axes[2].set_title('Prediction')
                axes[2].axis('off')

                plt.tight_layout()
                plt.savefig(os.path.join(config.analysis_path, 'final_predictions', f'pred_{i}_{j}.png'))
                plt.close()

            # 只保存前几个批次的结果
            if i >= 2:
                break


# 预测函数 - 用于对新数据进行水体识别
def predict_waterbodies(model_path, data_path, output_path, config):
    # 创建输出目录
    os.makedirs(output_path, exist_ok=True)

    # 加载模型
    model = WaterNet()
    model.load_state_dict(torch.load(model_path))
    model.to(config.device)
    model.eval()

    # 定义预测时的数据转换
    transform = A.Compose([
        A.Resize(256, 256),
        A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])

    # 获取所有待预测的图像文件
    image_files = [os.path.join(data_path, f) for f in os.listdir(data_path)
                   if f.endswith(('.png', '.jpg', '.jpeg'))]

    print(f"找到 {len(image_files)} 张图像进行水体识别")

    # 预测每张图像
    with torch.no_grad():
        for image_file in tqdm(image_files, desc="预测中"):
            try:
                # 读取图像
                image = np.array(Image.open(image_file).convert('RGB'))
                image_name = os.path.basename(image_file)

                # 应用转换
                transformed = transform(image=image)
                input_tensor = transformed['image'].unsqueeze(0).to(config.device)

                # 模型预测
                output = model(input_tensor)
                output = torch.sigmoid(output) > 0.5

                # 保存预测结果
                pred_mask = output.squeeze().cpu().numpy().astype(np.uint8) * 255
                pred_image = Image.fromarray(pred_mask, mode='L')
                pred_image.save(os.path.join(output_path, f'{image_name}'))



            except Exception as e:
                print(f"处理图像 {image_file} 时出错: {e}")

    print(f"预测完成，结果已保存至 {output_path}")


# 主函数
if __name__ == "__main__":
    # 训练模型
    #train_waternet()

    # 如果需要对新数据进行预测，可以取消下面的注释并提供相应的参数
    predict_waterbodies(
        model_path=Config.save_path,
        data_path=Config.predict_data_path,
        output_path=r"E:\shuju_S2\消融实验\主干网络\prediction_results",
        config=Config()
    )